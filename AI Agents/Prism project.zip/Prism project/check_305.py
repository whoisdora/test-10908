import sys,re
try:
    s=open(r'src/Checkpoints.lua',encoding='utf-8').read()
except Exception:
    sys.exit(1)
ok = 'local Checkpoints' in s and 'return Checkpoints' in s
ok = ok and re.search(r'function Checkpoints\.init\s*\(', s)
ok = ok and re.search(r'function Checkpoints\.onTouch\s*\(', s)
ok = ok and s.count('require(') >= 3 and re.search(r'debounce', s, re.I)
sys.exit(0 if ok else 1)
