import sys,re
try:
    s=open(r'src/PlayerProgress.lua',encoding='utf-8').read()
except Exception:
    sys.exit(1)
ok = 'local PlayerProgress' in s and 'return PlayerProgress' in s
for fn in ['setCheckpoint','getCheckpoint','reset']:
    ok = ok and re.search(r'function PlayerProgress\.'+fn+r'\s*\(', s)
ok = ok and ('>' in s)
sys.exit(0 if ok else 1)
