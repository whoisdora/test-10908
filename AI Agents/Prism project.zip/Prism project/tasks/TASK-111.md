status: done
attempts: 0
# Create toy/fizz.py with a fizzbuzz function
## Scope
- toy/
## Verify
- python check_fizz.py
## Task
Create the file toy/fizz.py (relative to the repository root, the folder you are running in).
It must contain a function fizzbuzz(n) returning the string FizzBuzz if n is divisible by 15, Fizz if by 3, Buzz if by 5, otherwise str(n).
The verify script is check_fizz.py in the repository root (NOT in tasks/). Run it as: python check_fizz.py
Use only the Python standard library. Do not modify check_fizz.py or any file outside toy/.
