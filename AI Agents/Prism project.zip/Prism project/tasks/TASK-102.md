status: escalate
attempts: 2
# Toy task two, designed to always fail
## Scope
- toy/
## Verify
- python -c "import sys; sys.exit(1)"
