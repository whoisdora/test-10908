status: done
attempts: 0
# Toy task three, verify output exists
## Scope
- toy/
## Verify
- python toy_check.py
