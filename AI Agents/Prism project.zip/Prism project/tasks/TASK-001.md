status: done
attempts: 0
# Build vault_check.py memory file checker

## Scope
- vault_check.py
- test_vault_check.py

## Verify
- python -m unittest
- python vault_check.py

## Notes
Completed before the runner existed. Checks AGENTS.md, core/state.md,
core/decisions.md, templates/task.md for existence and format.
Historical: fixed by hand after overnight run left dead main() and a bogus float rule.