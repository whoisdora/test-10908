status: todo
attempts: 0
# Create src_coins/TeleportPad.lua
## Scope
- src_coins/
## Verify
- python check_tele.py
## Task
Create src_coins/TeleportPad.lua.
Function: TeleportPad.Teleport(player, x, y, z) which moves the player to the specified position.
The verify script is check_tele.py.
