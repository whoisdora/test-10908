status: done
attempts: 0
# Create lib/topwords.py with a stopword-aware frequency function
## Scope
- lib/
## Verify
- python check_top.py
## Task
Create the file lib/topwords.py (relative to the repository root, the folder you are running in).
It must contain top_words(text, n, stopwords) returning a list of (word, count) tuples for the n most frequent lowercased words not in the stopwords list, sorted by count descending then alphabetically. Words are whitespace-separated.
The verify script is check_top.py in the repository root (NOT in tasks/). Run it as: python check_top.py
Use only the Python standard library. Do not modify check_top.py or any file outside lib/.
