status: done
attempts: 2
# Create toy/temperature.py with conversion functions
## Scope
- toy/
## Verify
- python check_temp.py
## Task
Create the file toy/temperature.py (relative to the repository root, the folder you are running in).
It must contain two functions: c_to_f(c) converting Celsius to Fahrenheit using f = c * 9/5 + 32, and f_to_c(f) converting Fahrenheit to Celsius using c = (f - 32) * 5/9.
Both must return floats, so c_to_f(0) returns 32.0 and f_to_c(32) returns 0.0.
The verify script is check_temp.py in the repository root (NOT in tasks/). Run it as: python check_temp.py
Use only the Python standard library. Do not modify check_temp.py or any file outside toy/.
