status: done
attempts: 0
# Create src/SpawnLogic.lua using Registry and Progress
## Scope
- src/
## Verify
- python check_304.py
## Task
Create the file src/SpawnLogic.lua (relative to the repository root, the folder you are running in).
Roblox Luau ModuleScript: local SpawnLogic = {}, return SpawnLogic at the end.
The files src/CheckpointRegistry.lua, src/PlayerProgress.lua and src/Config.lua ALREADY EXIST, created by earlier tasks. Do not search or glob for them, just require them: local CheckpointRegistry = require(script.Parent.CheckpointRegistry) and similar for PlayerProgress and Config.
Function: SpawnLogic.getRespawnCFrame(player) which gets the player checkpoint number from PlayerProgress, looks the part up in CheckpointRegistry, and returns part.CFrame plus a Y offset of Config.SPAWN_OFFSET_Y using CFrame.new(0, Config.SPAWN_OFFSET_Y, 0). Return nil when the player has no checkpoint.
The verify script is check_304.py in the repository root (NOT in tasks/). Run it as: python check_304.py
Do not modify check_304.py or any file outside src/.
