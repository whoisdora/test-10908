status: escalate
attempts: 2
# Coin Touch Collection
## Scope
- src_coins/
## Verify
- bin\luau.exe check_402.lua
## Task
Create the file src_coins/CoinPicker.lua (relative to the repository root).
It is a Luau module: declare a local table, define the functions, return the table. No Roblox Instances, no game services, pure logic only.
Spec: CoinPicker.OnTouch(player) adds exactly 1 coin to that player via PlayerCoinTracker.AddCoins. Load the dependency with loadfile.
Checks it must satisfy: one touch equals one coin, two touches equal two coins
The dependency files (PlayerCoinTracker.lua) ALREADY EXIST from earlier tasks. Do not search or glob for them. In plain luau tests they are loaded by the checker, your module must only require/return cleanly.
The checker is check_402.lua in the repository root (NOT in tasks/). Run it as: bin\luau.exe check_402.lua
Do not modify check_402.lua or any file outside src_coins/.
