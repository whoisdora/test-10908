status: escalate
attempts: 2
attempts: 0

\# Delay Configuration

\## Scope

\- src\_coins/

\## Verify

\- bin\\luau.exe check\_404.lua

\## Task

Create src\_coins/Config.lua.

It must be a Luau module returning a table with {RESPAWN\_DELAY = 5}.

The checker is check\_404.lua in the root.

