status: done
attempts: 2
# Finish per-checkpoint debounce in Checkpoints.lua, both read and write
## Scope
- src/
## Verify
- python check_306.py
## Task
Edit the EXISTING file src/Checkpoints.lua (relative to the repository root). Keep all functions and requires intact.
The debounce WRITE line already uses the compound key: debounce[player.UserId .. ':' .. checkpointNumber] = now. That line is correct, keep it.
The debounce READ line is still wrong: local last = debounce[player.UserId]. Change it to use the SAME compound key: local last = debounce[player.UserId .. ':' .. checkpointNumber]
After editing, RUN the verify command yourself with the bash tool and confirm exit code 0 before stopping: python check_306.py
The verify script is check_306.py in the repository root (NOT in tasks/).
Do not modify check_306.py or any file outside src/.
