status: done
attempts: 2
# Create src/Checkpoints.lua facade with debounced onTouch
## Scope
- src/
## Verify
- python check_305.py
## Task
Create the file src/Checkpoints.lua (relative to the repository root, the folder you are running in).
Roblox Luau ModuleScript: local Checkpoints = {}, return Checkpoints at the end.
The files src/Config.lua, src/CheckpointRegistry.lua, src/PlayerProgress.lua and src/SpawnLogic.lua ALREADY EXIST from earlier tasks. Do not search or glob for them, require them via script.Parent like: local Config = require(script.Parent.Config).
Functions: Checkpoints.init() which returns the module table for chaining, Checkpoints.onTouch(checkpointNumber, player) which uses a debounce table keyed by player.UserId with a cooldown of Config.RESPAWN_DELAY seconds (use os.clock() for timing) and calls PlayerProgress.setCheckpoint(player, checkpointNumber) when not debounced, Checkpoints.getRespawnCFrame(player) which just forwards to SpawnLogic.getRespawnCFrame(player).
The verify script is check_305.py in the repository root (NOT in tasks/). Run it as: python check_305.py
Do not modify check_305.py or any file outside src/.
