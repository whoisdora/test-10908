status: done
attempts: 0
# Create toy/pal.py with an is_palindrome function
## Scope
- toy/
## Verify
- python check_pal.py
## Task
Create the file toy/pal.py (relative to the repository root, the folder you are running in).
It must contain a function is_palindrome(text) returning True if text reads the same forwards and backwards IGNORING spaces and letter case, else False. Example: A man a plan a canal Panama returns True.
The verify script is check_pal.py in the repository root (NOT in tasks/). Run it as: python check_pal.py
Use only the Python standard library. Do not modify check_pal.py or any file outside toy/.
