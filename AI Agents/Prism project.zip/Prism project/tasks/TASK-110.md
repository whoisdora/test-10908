status: done
attempts: 2
# Create toy/reverser.py with a reverse_words function
## Scope
- toy/
## Verify
- python check_rev.py
## Task
Create the file toy/reverser.py (relative to the repository root, the folder you are running in).
It must contain a function reverse_words(text) that returns the words of text in reverse order joined by single spaces. reverse_words('hello world') returns 'world hello'. A single word returns itself. An empty string returns an empty string.
The verify script is check_rev.py in the repository root (NOT in tasks/). Run it as: python check_rev.py
Use only the Python standard library. Do not modify check_rev.py or any file outside toy/.
