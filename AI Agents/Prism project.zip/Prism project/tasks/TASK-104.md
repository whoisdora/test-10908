status: done
attempts: 1
# Toy task four, hang test target
## Scope
- toy/
## Verify
- python toy_check.py
