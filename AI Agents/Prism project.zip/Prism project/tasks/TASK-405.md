status: todo

attempts: 0

\# Coin Respawn Manager

\## Scope

\- src\_coins/

\## Verify

\- bin\\luau.exe check\_405.lua

\## Task

Create src\_coins/RespawnManager.lua.

Dependencies: Config.lua (already exists). Load with: local Config = require("./Config")

Functions: 

\- OnCollected(coinId) adds coinId to a pending table.

\- GetPending() returns the count of pending coins.

\- Tick(elapsed) increments pending coin times, returns a list of coinIds where time >= Config.RESPAWN\_DELAY, and removes them from pending.

The checker is check\_405.lua in the root.

