status: done
attempts: 0
# Create toy/calc.py with add and sub functions
## Scope
- toy/
## Verify
- python check_calc.py
## Task
Create the file toy/calc.py (relative to the repository root, the folder you are running in).
It must contain two functions: add(a, b) returning a plus b, and sub(a, b) returning a minus b.
The verify script is check_calc.py in the repository root (NOT in tasks/). Run it as: python check_calc.py
Use only the Python standard library. Do not modify check_calc.py or any file outside toy/.
