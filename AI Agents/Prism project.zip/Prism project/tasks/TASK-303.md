status: done
attempts: 0
# Create src/PlayerProgress.lua
## Scope
- src/
## Verify
- python check_303.py
## Task
Create the file src/PlayerProgress.lua (relative to the repository root, the folder you are running in).
Roblox Luau ModuleScript: local PlayerProgress = {} with an internal table keyed by player.UserId, return PlayerProgress at the end.
Functions: PlayerProgress.setCheckpoint(player, number) which only updates when number is GREATER THAN the stored value (forward-only, use a > comparison), PlayerProgress.getCheckpoint(player) returning the stored number or 0, PlayerProgress.reset(player) clearing the entry.
The verify script is check_303.py in the repository root (NOT in tasks/). Run it as: python check_303.py
Do not modify check_303.py or any file outside src/.
