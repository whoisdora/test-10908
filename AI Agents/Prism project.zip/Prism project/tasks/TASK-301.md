status: done
attempts: 0
# Create src/Config.lua constants module
## Scope
- src/
## Verify
- python check_301.py
## Task
Create the file src/Config.lua (relative to the repository root, the folder you are running in).
It is a Roblox Luau ModuleScript: declare local Config = {}, set fields, end with return Config.
Required fields: Config.RESPAWN_DELAY = 3, Config.CHECKPOINT_TAG = 'Checkpoint', Config.SPAWN_OFFSET_Y = 5.
The verify script is check_301.py in the repository root (NOT in tasks/). Run it as: python check_301.py
Do not modify check_301.py or any file outside src/.
