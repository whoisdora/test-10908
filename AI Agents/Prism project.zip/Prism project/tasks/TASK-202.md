status: done
attempts: 0
# Create lib/readability.py with average length functions
## Scope
- lib/
## Verify
- python check_read.py
## Task
Create the file lib/readability.py (relative to the repository root, the folder you are running in).
It must contain: avg_word_length(text) returning the mean length of whitespace-separated words as a float (0.0 for empty text), and avg_sentence_length(text) returning the mean number of words per sentence as a float, sentences split on . ! or ? ignoring empty ones.
The verify script is check_read.py in the repository root (NOT in tasks/). Run it as: python check_read.py
Use only the Python standard library. Do not modify check_read.py or any file outside lib/.
