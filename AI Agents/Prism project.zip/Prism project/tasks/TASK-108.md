status: done
attempts: 2
# Create toy/wordcount.py with a count_words function
## Scope
- toy/
## Verify
- python check_wc.py
## Task
Create the file toy/wordcount.py (relative to the repository root, the folder you are running in).
It must contain a function count_words(text) that returns the number of words in text, where words are separated by whitespace. An empty string returns 0. Leading and trailing spaces must not create extra words. Hint: str.split() with no arguments handles this.
The verify script is check_wc.py in the repository root (NOT in tasks/). Run it as: python check_wc.py
Use only the Python standard library. Do not modify check_wc.py or any file outside toy/.
