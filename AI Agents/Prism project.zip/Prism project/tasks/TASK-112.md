status: done
attempts: 0
# Create toy/vowels.py with a count_vowels function
## Scope
- toy/
## Verify
- python check_vowel.py
## Task
Create the file toy/vowels.py (relative to the repository root, the folder you are running in).
It must contain a function count_vowels(text) returning how many characters of text are vowels (a e i o u), counting BOTH uppercase and lowercase.
The verify script is check_vowel.py in the repository root (NOT in tasks/). Run it as: python check_vowel.py
Use only the Python standard library. Do not modify check_vowel.py or any file outside toy/.
