status: done
attempts: 0
# Create lib/ngrams.py with a bigram function
## Scope
- lib/
## Verify
- python check_ngrams.py
## Task
Create the file lib/ngrams.py (relative to the repository root, the folder you are running in).
It must contain bigrams(text) returning a list of (word, next_word) tuples for consecutive whitespace-separated words. A single word or empty text returns an empty list.
The verify script is check_ngrams.py in the repository root (NOT in tasks/). Run it as: python check_ngrams.py
Use only the Python standard library. Do not modify check_ngrams.py or any file outside lib/.
