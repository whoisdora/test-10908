status: done
attempts: 0
attempts: 0

\# Spend Validation

\## Scope

\- src\_coins/

\## Verify

\- bin\\luau.exe check\_403.lua

\## Task

Create src\_coins/SpendService.lua. 

It must be a Luau module: declare a local table, define the function, return the table.

The dependency src\_coins/PlayerCoinTracker.lua ALREADY EXISTS. Load it with: local PlayerCoinTracker = require("./PlayerCoinTracker")

Function: SpendService.CanSpend(player, amount) returns true if PlayerCoinTracker.GetPlayerCoins(player) >= amount, else false.

The checker is check\_403.lua in the root. 

