status: done
attempts: 2
# Create toy/greet.py with a greet function
## Scope
- toy/
## Verify
- python check_greet.py
## Task
Create the file toy/greet.py containing a function greet(name) that returns the string Hello, {name}! so greet('World') returns Hello, World!
Use only the Python standard library. Do not modify check_greet.py or any file outside toy/.
