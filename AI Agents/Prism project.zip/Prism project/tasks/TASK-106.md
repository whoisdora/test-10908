status: done
attempts: 0
# Create toy/farewell.py with a farewell function
## Scope
- toy/
## Verify
- python check_fare.py
## Task
Create the file toy/farewell.py (relative to the repository root, the folder you are running in).
It must contain a function farewell(name) that returns the string Goodbye, {name}! so farewell('World') returns Goodbye, World!
The verify script is check_fare.py in the repository root (NOT in tasks/). Run it as: python check_fare.py from the root folder.
Use only the Python standard library. Do not modify check_fare.py or any file outside toy/.
