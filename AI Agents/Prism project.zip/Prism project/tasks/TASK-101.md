status: done
attempts: 1
# Toy task one, create output file
## Scope
- toy/
## Verify
- python toy_check.py
