status: done
attempts: 0
# Create lib/counts.py with word, sentence and char counters
## Scope
- lib/
## Verify
- python check_counts.py
## Task
Create the file lib/counts.py (relative to the repository root, the folder you are running in).
It must contain: word_count(text) returning the number of whitespace-separated words, sentence_count(text) returning the number of sentences split on . ! or ? (ignore empty ones), char_count(text) returning len(text).
The verify script is check_counts.py in the repository root (NOT in tasks/). Run it as: python check_counts.py
Use only the Python standard library. Do not modify check_counts.py or any file outside lib/.
