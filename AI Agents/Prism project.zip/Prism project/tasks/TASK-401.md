status: todo
attempts: 1
# Create src_coins/HealthModule.lua
## Scope
- src_coins/
## Verify
- bin\luau.exe check_401.lua
## Task
Create the file src_coins/HealthModule.lua. It must return a table with a method: HealthModule.New(initialHealth). The table must maintain the health value and have a method :TakeDamage(amount) which subtracts health (min 0) and :GetHealth() returning current health.
