status: todo
attempts: 0
# Create src_coins/KillPart.lua
## Scope
- src_coins/
## Docs
- notes/docs/Part.md
## Verify
- python check_kill.py
## Task
Read notes/docs/Part.md. Create src_coins/KillPart.lua.
Function: KillPart.OnTouch(player) which kills the player (find the Humanoid in player.Character, set Health to 0).
Worker must reference the Part API properly.
The verify script is check_kill.py.
