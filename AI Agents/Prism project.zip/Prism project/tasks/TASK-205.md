status: done
attempts: 2
# Create lib/report.py combining the earlier modules
## Scope
- lib/
## Verify
- python check_report.py
## Task
Create the file lib/report.py (relative to the repository root, the folder you are running in).
It must contain text_report(text) returning a dict with keys: words, sentences, chars, avg_word_length, avg_sentence_length.
Import and reuse the functions from lib/counts.py and lib/readability.py which already exist (created by TASK-201 and TASK-202). Use imports like: from counts import word_count
The verify script is check_report.py in the repository root (NOT in tasks/). Run it as: python check_report.py
Use only the Python standard library. Do not modify check_report.py or any file outside lib/.
