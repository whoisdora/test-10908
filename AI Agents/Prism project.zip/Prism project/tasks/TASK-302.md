status: done
attempts: 0
# Create src/CheckpointRegistry.lua
## Scope
- src/
## Verify
- python check_302.py
## Task
Create the file src/CheckpointRegistry.lua (relative to the repository root, the folder you are running in).
Roblox Luau ModuleScript: local CheckpointRegistry = {} with an internal table, return CheckpointRegistry at the end.
Functions: CheckpointRegistry.register(number, part) storing part by number and erroring on duplicate number, CheckpointRegistry.get(number) returning the stored part or nil, CheckpointRegistry.count() returning how many are registered.
The verify script is check_302.py in the repository root (NOT in tasks/). Run it as: python check_302.py
Do not modify check_302.py or any file outside src/.
