import sys
sys.path.insert(0, 'toy')
try:
    from vowels import count_vowels
except Exception:
    sys.exit(1)
ok = count_vowels('hello')==2 and count_vowels('xyz')==0 and count_vowels('AEIOU')==5
sys.exit(0 if ok else 1)
