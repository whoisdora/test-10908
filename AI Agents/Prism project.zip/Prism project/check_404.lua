-- checker for src_coins/Config.lua
local Config = require('./src_coins/Config')
assert(type(Config) == 'table', 'module must return a table')
assert(type(Config.RESPAWN_DELAY) == 'number', 'RESPAWN_DELAY must be numeric')
assert(Config.RESPAWN_DELAY == 5, 'RESPAWN_DELAY must default to 5')
print('CHECK 404 PASS')