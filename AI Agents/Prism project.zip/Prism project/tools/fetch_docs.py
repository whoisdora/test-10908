import sys, urllib.request, pathlib, re

def fetch(url, target_name):
    print(f"Fetching {target_name}...")
    try:
        with urllib.request.urlopen(url) as response:
            html = response.read().decode('utf-8')
            # Extract basic text
            text = re.sub('<[^<]+?>', ' ', html)
            text = re.sub('\s+', ' ', text)
            out = pathlib.Path(f"notes/docs/{target_name}.md")
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(f"# {target_name}\n\n{text}", encoding='utf-8')
            print(f"Saved to {out}")
    except Exception as e:
        print(f"Failed to fetch {url}: {e}")

if __name__ == "__main__":
    # Usage: python tools/fetch_docs.py <url> <name>
    fetch(sys.argv[1], sys.argv[2])