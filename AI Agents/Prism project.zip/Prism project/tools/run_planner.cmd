@echo off
if "%~1"=="" echo usage: run_planner.cmd "Your Goal" & exit /b 1
echo Planning: %~1
opencode run --variant minimal "Read templates/planner_prompt.md and follow it exactly. Write core/spec_proposed.md and task files into the tasks_proposed folder as TASK-401.md upward. Also write the checkers as check_NNN.lua scripts. GOAL: %~1"
python tools\plan_compile.py tasks_proposed 401
echo Plan compiled. Linting now:
python tools\plan_lint.py tasks_proposed