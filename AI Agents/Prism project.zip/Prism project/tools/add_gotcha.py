import sys, pathlib
msg = " ".join(sys.argv[1:])
p = pathlib.Path("AGENTS.md")
content = p.read_text(encoding="utf-8")
if "## GOTCHAS" not in content:
    content += "\n## GOTCHAS\n"
content += f"- {msg}\n"
p.write_text(content, encoding="utf-8")
print(f"GOTCHA recorded: {msg}")