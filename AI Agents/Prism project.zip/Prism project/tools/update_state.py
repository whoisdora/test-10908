"""Update core/state.md safely. Usage:
  python tools/update_state.py --metrics "5 | 2 of 5 | 3 escalated | -"
  python tools/update_state.py --touch
Sets updated: to today. Appends a metrics row if given. Refuses to save an invalid file."""
import argparse, datetime, pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
STATE = ROOT / "core" / "state.md"
sys.path.insert(0, str(ROOT))
from vault_check import check_state_date_format, check_state_line_count

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--metrics", help="row WITHOUT the date, pipes between fields")
    ap.add_argument("--touch", action="store_true", help="only refresh the updated: date")
    a = ap.parse_args()
    if not a.metrics and not a.touch:
        ap.error("nothing to do: give --metrics or --touch")
    today = datetime.date.today().isoformat()
    original = STATE.read_text(encoding="utf-8")
    lines = original.splitlines()
    for i, ln in enumerate(lines):
        if ln.strip().startswith("updated:"):
            lines[i] = f"updated: {today}"
            break
    else:
        sys.exit("FAIL: no updated: line found, file needs manual repair")
    if a.metrics:
        lines.append(f"{today} | {a.metrics.strip()}")
    STATE.write_text("\n".join(lines) + "\n", encoding="utf-8")
    problems = [r for r in check_state_date_format(str(ROOT)) + check_state_line_count(str(ROOT))
                if r.startswith("FAIL")]
    if problems:
        STATE.write_text(original, encoding="utf-8")
        sys.exit("FAIL: change rolled back: " + "; ".join(problems))
    print(f"OK: state.md updated {today}" + (" + metrics row" if a.metrics else ""))

if __name__ == "__main__":
    main()