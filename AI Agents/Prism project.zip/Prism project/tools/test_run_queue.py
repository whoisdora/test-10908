"""Unit tests for run_queue.py. Run: python -m unittest discover -s tools"""
import subprocess, sys, tempfile, unittest
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_queue as rq

GOOD = """status: todo
attempts: 0
# Example task
## Scope
- src/thing.py
- docs/
## Verify
- python -m unittest
- python check.py
"""

def make_task(d, n, status="todo", attempts=0, scope="- out.txt", verify="- python -c pass"):
    p = Path(d) / f"TASK-{n:03d}.md"
    p.write_text(f"status: {status}\nattempts: {attempts}\n# Task {n}\n"
                 f"## Scope\n{scope}\n## Verify\n{verify}\n", encoding="utf-8")
    return p

class ParseTask(unittest.TestCase):
    def test_full(self):
        t = rq.parse_task(GOOD)
        self.assertEqual(t["status"], "todo"); self.assertEqual(t["attempts"], 0)
        self.assertEqual(t["title"], "Example task")
        self.assertEqual(t["scope"], ["src/thing.py", "docs/"])
        self.assertEqual(t["verify"], ["python -m unittest", "python check.py"])
    def test_default_verify(self):
        t = rq.parse_task("status: todo\nattempts: 1\n# X\n## Scope\n- a.py\n")
        self.assertEqual(t["verify"], ["python -m unittest"])
    def test_bad_header(self):
        with self.assertRaises(ValueError): rq.parse_task("# no header\nstatus: todo\n")
        with self.assertRaises(ValueError): rq.parse_task("status: todo\n")

class PickOrder(unittest.TestCase):
    def test_lowest_todo(self):
        with tempfile.TemporaryDirectory() as d:
            make_task(d, 1, status="done"); make_task(d, 10); make_task(d, 2)
            f, _ = rq.pick_next(d)
            self.assertEqual(f.name, "TASK-002.md")
    def test_empty_queue(self):
        with tempfile.TemporaryDirectory() as d:
            f, t = rq.pick_next(d)
            self.assertIsNone(f); self.assertIsNone(t)
    def test_all_done_or_escalate(self):
        with tempfile.TemporaryDirectory() as d:
            make_task(d, 1, status="done"); make_task(d, 2, status="escalate")
            self.assertIsNone(rq.pick_next(d)[0])

class Headers(unittest.TestCase):
    def test_attempt_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            p = make_task(d, 1)
            rq.write_header(p, "todo", 1)
            t = rq.parse_task(p.read_text(encoding="utf-8"))
            self.assertEqual((t["status"], t["attempts"]), ("todo", 1))
            rq.write_header(p, "escalate", 2)
            t = rq.parse_task(p.read_text(encoding="utf-8"))
            self.assertEqual((t["status"], t["attempts"]), ("escalate", 2))

class ScopeCheck(unittest.TestCase):
    def test_violations(self):
        scope = ["src/a.py", "docs/"]
        self.assertEqual(rq.scope_violations(["src/a.py", "docs/x/y.md"], scope), [])
        self.assertEqual(rq.scope_violations(["src/b.py"], scope), ["src/b.py"])
        self.assertEqual(rq.scope_violations(["opencode.json"], scope), ["opencode.json"])
    def test_prefix_not_fooled(self):
        self.assertEqual(rq.scope_violations(["docs2/x.md"], ["docs/"]), ["docs2/x.md"])

class StopRules(unittest.TestCase):
    def test_each_rule(self):
        base = dict(start=0, now=0, processed=0, consec_fails=0, stop_file=False,
                    max_hours=8, max_tasks=50, max_fails=3)
        self.assertEqual(rq.should_stop(**base), "")
        self.assertIn("STOP", rq.should_stop(**{**base, "stop_file": True}))
        self.assertIn("wall-clock", rq.should_stop(**{**base, "now": 8 * 3600}))
        self.assertIn("task limit", rq.should_stop(**{**base, "processed": 50}))
        self.assertIn("consecutive", rq.should_stop(**{**base, "consec_fails": 3}))

def init_repo(d):
    for args in (["init", "-b", "master"], ["config", "user.email", "t@t"],
                 ["config", "user.name", "t"]):
        subprocess.run(["git", *args], cwd=d, capture_output=True, check=True)

def cfg(root, worker, **kw):
    base = dict(root=root, worker_cmd=worker, max_hours=1.0, max_tasks=50, max_fails=3,
                task_timeout=60, verify_timeout=60, reviewer=False, dry_run=False)
    base.update(kw); return SimpleNamespace(**base)

class Integration(unittest.TestCase):
    def test_success_commits_on_agent_branch(self):
        with tempfile.TemporaryDirectory() as d, tempfile.TemporaryDirectory() as aux:
            root = Path(d); init_repo(d)
            (root / "tasks").mkdir()
            make_task(root / "tasks", 1, scope="- out.txt",
                      verify=f'- python "{Path(aux) / "check.py"}"')
            (Path(aux) / "fake.py").write_text(
                "open('out.txt','w').write('x')\n", encoding="utf-8")
            (Path(aux) / "check.py").write_text(
                "import pathlib,sys; sys.exit(0 if pathlib.Path('out.txt').exists() else 1)\n",
                encoding="utf-8")
            subprocess.run(["git", "add", "-A"], cwd=d, capture_output=True, check=True)
            subprocess.run(["git", "commit", "-m", "baseline"], cwd=d,
                           capture_output=True, check=True)
            master = subprocess.run(["git", "rev-parse", "master"], cwd=d,
                                    capture_output=True, text=True).stdout.strip()
            rq.run_loop(cfg(d, f'python "{Path(aux) / "fake.py"}"'))
            branch = subprocess.run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=d,
                                    capture_output=True, text=True).stdout.strip()
            self.assertTrue(branch.startswith("agent/"))
            t = rq.parse_task((root / "tasks" / "TASK-001.md").read_text(encoding="utf-8"))
            self.assertEqual(t["status"], "done")
            master_now = subprocess.run(["git", "rev-parse", "master"], cwd=d,
                                        capture_output=True, text=True).stdout.strip()
            self.assertEqual(master, master_now)

    def test_failing_task_escalates_after_two_attempts(self):
        with tempfile.TemporaryDirectory() as d, tempfile.TemporaryDirectory() as aux:
            root = Path(d); init_repo(d)
            (root / "tasks").mkdir()
            make_task(root / "tasks", 1, scope="- out.txt",
                      verify=f'- python "{Path(aux) / "fail.py"}"')
            (Path(aux) / "noop.py").write_text("pass\n", encoding="utf-8")
            (Path(aux) / "fail.py").write_text("import sys; sys.exit(1)\n", encoding="utf-8")
            subprocess.run(["git", "add", "-A"], cwd=d, capture_output=True, check=True)
            subprocess.run(["git", "commit", "-m", "baseline"], cwd=d,
                           capture_output=True, check=True)
            rq.run_loop(cfg(d, f'python "{Path(aux) / "noop.py"}"'))
            t = rq.parse_task((root / "tasks" / "TASK-001.md").read_text(encoding="utf-8"))
            self.assertEqual(t["status"], "escalate")
            self.assertEqual(t["attempts"], 2)

if __name__ == "__main__":
    unittest.main()