status: todo

attempts: 0

\# Short task title



\## Scope

\- file/or/folder/the/worker/may/touch.py



\## Verify

\- python -m unittest



\## Task

What to do, in a few plain sentences.



\## Acceptance

\- checkable fact

\- checkable fact

