import sys
sys.path.insert(0, 'toy')
try:
    from pal import is_palindrome
except Exception:
    sys.exit(1)
ok = is_palindrome('racecar') and not is_palindrome('hello') and is_palindrome('A man a plan a canal Panama')
sys.exit(0 if ok else 1)
