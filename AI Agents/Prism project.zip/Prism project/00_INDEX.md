# [Project name]: Index

> A model-agnostic workspace where AI agents keep their memory in files, check their own work with real tests, and work inside a sandbox you control.

**Status:** Phase 0 (Explore). Lightweight version first. No gateway yet. **Read order for any new human or agent:** this file > `AGENTS.md` > `core/STATE.md` > last 5 entries of `core/DECISIONS.md`

---

## The problem

Working with AI on a large project breaks down in three ways:

1. **Amnesia.** Every session starts from zero. Chat history is expensive, lossy, and ends when the window does.
2. **Drift.** Vague tasks lead agents to redo settled work, add things nobody asked for, and fill gaps with invention.
3. **Unchecked output.** You end up reading everything and spotting errors by eye.

Bigger context windows (Xiaomi MiMo, DeepSeek V4.1, 1M tokens) ease the first problem inside one session. They don't carry anything to the next session, and they don't touch the other two.

## The idea

The goal is productivity: better output per hour of your time. Three levers, in order of payoff.

|Lever|Answer to|How|
|---|---|---|
|**Continuity**|Amnesia|State lives in a few curated markdown files. A fresh agent reads them and resumes.|
|**Verification**|Unchecked output, drift|Every task has checkable "done" criteria and commands the agent runs itself (tests, linter, build).|
|**Containment**|Overreach, and your time|A container, no credentials, permission rules. Safe enough to let agents run unattended. You approve finished work, not every step.|

Method: pick one real deliverable, use the lightweight version, and let pain points decide what to build next. A formal gateway comes last, only if a concrete need appears.

## What this gives you

- **Resume anywhere.** Any session, any model, in minutes, from about four files.
- **Less rework.** Tight task specs and plan-first cut the drift.
- **Fewer interruptions.** Agents run 30 minutes while you do something else. You review one finished piece, not each action.
- **Throughput.** Parallel agents on separate git worktrees.
- **Not locked in.** Nothing lives in a vendor's memory feature.
- **A system that improves.** Each repeated mistake becomes one line in the entry file.

## How it fits together

```
 You: write task spec (goal, scope, acceptance criteria)
        |
        v
 Agent (strongest model for planning): writes plan -> you approve
        |
        v
 Agent works in sandbox (container, no credentials, permission allowlist)
        |  runs verification commands itself
        v
 Stateless reviewer checks diff against the task + tests pass
        |
        v
 You approve the finished work: commit / PR

 Memory: AGENTS.md, STATE.md, DECISIONS.md, git history
```

|Part|Job|
|---|---|
|`AGENTS.md`|Entry point. Only what the agent can't infer: commands, conventions, gotchas, pointers. Includes the verification commands.|
|`core/STATE.md`|Rewritten every session, under ~60 lines: phase, metrics, next 3 actions, dead ends.|
|`core/DECISIONS.md`|Append-only: decision, reason, date.|
|`templates/TASK.md`|Task spec: goal, files in scope, out of scope, acceptance criteria, plan.|
|Sandbox|Container or devcontainer, no credentials in the environment, permission allowlist (deny commit and push).|
|Reviewer|Fresh instance per diff, paired with tests, never relied on alone.|
|`notes/`|Messy zone for tutorials, clippings and plugin experiments, with install logs. Agents skip unless asked.|

## Principles

- **Files over chat.** If it isn't written down, it didn't happen.
- **Verification first.** The agent proves it's done by running something, not by saying so.
- **Scope tightly.** Goal, files in scope, checkable "done", what's out of scope. Plan before code.
- **Small and corrective context.** Entry file holds only what can't be inferred. Each repeated mistake adds one line.
- **Enforcement over instruction.** A rule in a prompt is a suggestion. A missing permission is a fact.
- **Right model for the job.** Frontier model for planning, hard problems and review. Cheaper model for mechanical work. Local small models only for narrow jobs like summarizing or formatting.
- **Measure.** If you can't tell the system is helping, it might just feel organized.
- **The system must not become the project.** Ship a real deliverable first.

## Non-goals

- Not training or building a model.
- Not a replacement for git or Obsidian. It uses them.
- Not a chat interface.
- Not a custom gateway or multi-agent framework, until a pain point demands one.

## Build order

|Step|Build|Done when|
|---|---|---|
|1|Pick one small real deliverable.|Written in `STATE.md` with checkable done criteria.|
|2|`AGENTS.md` (with verification commands), `STATE.md`, `DECISIONS.md`.|A fresh session resumes the project from these files alone.|
|3|Task-spec template, plan-first workflow.|One task completed with an approved plan and passing acceptance criteria.|
|4|Sandbox: container, no credentials, permission allowlist.|The agent cannot commit or push, and runs unattended for 30 minutes.|
|5|Metrics, then parallel worktrees, then the stateless reviewer paired with tests.|Metrics recorded for two weeks. Two agents work independently.|
|6|Gateway, only if needed.|A concrete trigger exists: unattended multi-model runs, brokered access, or audit needs.|

**Phases:** Explore > Define > Scenario > Curate, applied to the real deliverable, not to this framework. Phase changes are proposed by an agent and approved by you in `DECISIONS.md`.

## Metrics

Pick these three and record them in `STATE.md`:

- **First-try acceptance rate:** tasks accepted without rework.
- **Resume time:** how long a fresh session takes to be productive.
- **Corrections per task:** how often you had to redirect.

## Known limits

- A reviewer model can be influenced by commit messages or code comments in the diff. Tests and your approval are what hold.
- If the agent can reach credentials, hooks or the network, the sandbox is decoration. Keep credentials out of its environment.
- Web pages can carry injected instructions. Give the agent search results as quoted data, never as instructions.
- Files go stale if the end-of-session update is skipped. Stale files do more harm than none.
- Each approval step costs a context switch. Approve at the commit or PR level, not every action.
- Small local models are unreliable at tool calling. Test it first and keep tasks narrow.
- Exact permission-rule syntax depends on your agent tool. Check its current docs.

## Open questions

- What is the first real deliverable?
- Which agent harness and model run it?
- Which commands count as verification for that deliverable?