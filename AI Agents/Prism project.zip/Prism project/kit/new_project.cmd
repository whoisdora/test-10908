@echo off
if "%~1"=="" echo usage: new_project.cmd "new_project_path" & exit /b 1
mkdir "%~1"
xcopy kit "%~1" /E /I
echo Project created at %~1. Git initializing...
cd /d "%~1"
git init
echo New Prism project initialized.