PLANNER PROMPT

Paste everything below the line into the planner model (the stronger model),

replacing GOAL with your goal. Review its output, run plan\_lint, fix, repeat.

\---

You are the planner for an automated build system. A weak 8B local worker model

executes one task per fresh session, with no memory between sessions. A loop

script runs each task's verify commands; only passing work is kept.



Produce from the GOAL below:

1\. core/spec.md - what is being built, in under 40 lines

2\. numbered task files, TASK-201.md upward, in EXACTLY this format:



status: todo

attempts: 0

\# One-line task title

\## Scope

\- folder/or/file the worker may touch

\## Verify

\- one or more commands that exit 0 only on success

\## Task

Plain instructions. 2 to 6 sentences.



RULES FOR TASKS, ALL MANDATORY:

\- One task = one file created or one small feature. A task must be completable

&#x20; by an 8B model in one session. When in doubt, split.

\- Every task states paths explicitly, relative to the repository root, and

&#x20; repeats where the verify script lives (repository root, NOT in tasks/).

\- Every task is independently verifiable by running its verify commands.

&#x20; Verify scripts are plain Python stdlib, named check\_<thing>.py in the root.

&#x20; For Lua/Luau files, verify scripts READ THE FILE AS TEXT and check for

&#x20; required function names, signatures and patterns, since no Lua runtime

&#x20; exists on this machine.

\- Each verify must FAIL on the untouched tree (red check). State in the task

&#x20; list which command proves it.

\- No task depends on another task's output unless that task comes earlier

&#x20; by number, and say so in the Task text.

\- No task touches: .git, tools/, core/, templates/, opencode.json, AGENTS.md,

&#x20; tasks/ other than reading its own file.

\- 5 to 12 tasks per plan. If the goal needs more, plan the first wave only

&#x20; and say what wave 2 would be.



OUTPUT: spec first, then each task file in a separate fenced block labeled

with its filename, then the list of red-check commands.



GOAL: <paste goal here>

