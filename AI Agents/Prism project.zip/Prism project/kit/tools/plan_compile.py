"""Compile planner MODULE blocks into task files + luau checkers.
Usage: python tools/plan_compile.py plan.txt <start_number>
Reads MODULE lines, writes tasks_proposed/TASK-NNN.md and check_NNN.lua stubs.
Human reviews both before promoting to tasks/."""
import sys, re, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent

def parse(text):
    mods = []
    for line in text.splitlines():
        if not line.strip().startswith("MODULE:"):
            continue
        fields = {}
        for part in line.split("|"):
            k, _, v = part.strip().partition(":")
            fields[k.strip().upper()] = v.strip()
        if fields.get("MODULE"):
            mods.append(fields)
    return mods

def main():
    plan_file, start = sys.argv[1], int(sys.argv[2])
    mods = parse(pathlib.Path(plan_file).read_text(encoding="utf-8-sig"))
    if not mods:
        sys.exit("no MODULE lines found")
    outdir = ROOT / "tasks_proposed"
    outdir.mkdir(exist_ok=True)
    for i, m in enumerate(mods):
        n = start + i
        fname = m["MODULE"]
        folder = fname.split("/")[0] + "/"
        deps = m.get("DEPENDS", "none")
        dep_note = ""
        if deps.lower() != "none":
            dep_note = (f"\nThe dependency files ({deps}) ALREADY EXIST from earlier tasks. "
                        "Do not search or glob for them. In plain luau tests they are loaded "
                        "by the checker, your module must only require/return cleanly.")
        task = (f"status: todo\nattempts: 0\n# {m.get('TITLE', fname)}\n"
                f"## Scope\n- {folder}\n## Verify\n- bin\\luau.exe check_{n}.lua\n"
                f"## Task\nCreate the file {fname} (relative to the repository root).\n"
                f"It is a Luau module: declare a local table, define the functions, return the table. "
                f"No Roblox Instances, no game services, pure logic only.\n"
                f"Spec: {m.get('SPEC', '')}\n"
                f"Checks it must satisfy: {m.get('CHECKS', '')}{dep_note}\n"
                f"The checker is check_{n}.lua in the repository root (NOT in tasks/). "
                f"Run it as: bin\\luau.exe check_{n}.lua\n"
                f"Do not modify check_{n}.lua or any file outside {folder}.\n")
        (outdir / f"TASK-{n}.md").write_text(task, encoding="utf-8")
        checker = (f"-- checker for {fname} - HUMAN: replace TODO asserts with real ones\n"
                   f"local m = loadfile('{fname}')()\n"
                   f"assert(type(m) == 'table', 'module must return a table')\n"
                   f"-- planner checks: {m.get('CHECKS', '')}\n"
                   f"-- TODO real asserts here\n"
                   f"print('CHECK {n} PASS')\n")
        (ROOT / f"check_{n}.lua").write_text(checker, encoding="utf-8")
        print(f"wrote TASK-{n}.md + check_{n}.lua for {fname}")

if __name__ == "__main__":
    main()