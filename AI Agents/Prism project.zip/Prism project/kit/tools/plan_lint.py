"""Lint task files before a run. Usage: python tools/plan_lint.py [tasks_dir]
Checks: parseable, has scope, has verify, scope doesn't touch control paths,
no two todo tasks share a scope entry, verify scripts exist where referenced."""
import re, sys, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
from run_queue import parse_task, task_files

FORBIDDEN = (".git", "tools", "core", "templates", "opencode.json", "agents.md")

def lint(tasks_dir):
    problems, scope_owner = [], {}
    files = task_files(tasks_dir)
    if not files:
        return ["FAIL: no task files found in " + str(tasks_dir)]
    for f in files:
        try:
            t = parse_task(f.read_text(encoding="utf-8-sig"))
        except ValueError as e:
            problems.append(f"FAIL: {f.name}: unparseable ({e})")
            continue
        if t["status"] not in ("todo", "done", "escalate"):
            problems.append(f"FAIL: {f.name}: bad status {t['status']!r}")
        if not t["scope"]:
            problems.append(f"FAIL: {f.name}: no Scope entries")
        if not t["title"]:
            problems.append(f"FAIL: {f.name}: no title line")
        for s in t["scope"]:
            low = s.lower().rstrip("/")
            if any(low == bad or low.startswith(bad + "/") for bad in FORBIDDEN):
                problems.append(f"FAIL: {f.name}: scope touches control path {s!r}")
            if t["status"] == "todo":
                if low in scope_owner:
                    problems.append(f"WARN: {f.name}: scope {s!r} overlaps todo task {scope_owner[low]}, fine sequentially, blocks parallel M10")
                else:
                    scope_owner[low] = f.name
        for v in t["verify"]:
            m = re.search(r"python\s+([\w./\\-]+\.py)", v)
            if m and not (ROOT / m.group(1)).exists():
                problems.append(f"FAIL: {f.name}: verify references missing file {m.group(1)}")
    fails=[x for x in problems if x.startswith("FAIL")]
    return problems if fails else (problems + ["OK: no FAILs, warnings only"] if problems else ["OK: all task files lint clean"])

if __name__ == "__main__":
    d = sys.argv[1] if len(sys.argv) > 1 else str(ROOT / "tasks")
    results = lint(d)
    for r in results:
        print(r)
    sys.exit(0 if any(r.startswith("OK") for r in results) else 1)