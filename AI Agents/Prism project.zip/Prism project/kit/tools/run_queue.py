"""run_queue.py - queue-mode loop. The loop commits; the worker never does.
Stdlib only. Windows Command Prompt environment. Paths may contain spaces."""
import argparse, datetime, re, subprocess, sys, time
from pathlib import Path

HEADER_RE = re.compile(r"^status:\s*([\w-]+)\s*$", re.I)
ATTEMPTS_RE = re.compile(r"^attempts:\s*(\d+)\s*$", re.I)
TASK_RE = re.compile(r"^TASK-(\d+)\.md$", re.I)
DEFAULT_VERIFY = ["python -m unittest"]
DEFAULT_WORKER = 'opencode run "{prompt}"'
with open(Path(__file__).parent / "prompt.txt", "r", encoding="utf-8") as f:
    PROMPT = f.read()
IGNORE_UNTRACKED = ("sessions/", "STOP")
MAX_ATTEMPTS = 2

# ---------- task files ----------

def parse_task(text):
    lines = [l for l in text.splitlines() if l.strip()]
    if len(lines) < 2:
        raise ValueError("task file shorter than two lines")
    m1 = HEADER_RE.match(lines[0]); m2 = ATTEMPTS_RE.match(lines[1])
    if not m1 or not m2:
        raise ValueError("first two lines must be 'status: <s>' and 'attempts: <n>'")
    title, scope, verify, section = "", [], [], ""
    for ln in lines[2:]:
        s = ln.strip()
        if s.lower().startswith("## scope"): section = "scope"; continue
        if s.lower().startswith("## verify"): section = "verify"; continue
        if s.startswith("## "): section = ""; continue
        if s.startswith("# ") and not title: title = s[2:].strip(); continue
        if s.startswith("- ") and section == "scope":
            scope.append(s[2:].strip().replace("\\", "/"))
        elif s.startswith("- ") and section == "verify":
            verify.append(s[2:].strip())
    return {"status": m1.group(1).lower(), "attempts": int(m2.group(1)),
            "title": title, "scope": scope, "verify": verify or list(DEFAULT_VERIFY)}

def write_header(path, status, attempts):
    lines = path.read_text(encoding="utf-8").splitlines()
    lines[0] = f"status: {status}"; lines[1] = f"attempts: {attempts}"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")

def task_files(tasks_dir):
    pairs = []
    for f in Path(tasks_dir).iterdir():
        m = TASK_RE.match(f.name)
        if m: pairs.append((int(m.group(1)), f))
    return [f for _, f in sorted(pairs)]

def pick_next(tasks_dir):
    """Lowest-numbered task with status todo. Unparseable files are skipped."""
    for f in task_files(tasks_dir):
        try:
            t = parse_task(f.read_text(encoding="utf-8"))
        except ValueError:
            continue
        if t["status"] == "todo":
            return f, t
    return None, None

# ---------- git ----------

def git(root, *args, check=False):
    r = subprocess.run(["git", *args], cwd=str(root), capture_output=True, text=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)}: {r.stderr.strip()}")
    return r

def porcelain_paths(root):
    paths = []
    for line in git(root, "status", "--porcelain").stdout.splitlines():
        if not line.strip(): continue
        p = line[3:]
        if " -> " in p: p = p.split(" -> ", 1)[1]
        paths.append(p.strip().strip('"').replace("\\", "/"))
    return paths

def is_ignored(p):
    return any(p == i.rstrip("/") or p.startswith(i) for i in IGNORE_UNTRACKED)

def dirty_paths(root):
    return [p for p in porcelain_paths(root) if not is_ignored(p)]

def scope_violations(changed, scope):
    def in_scope(p):
        return any(p == s or p.startswith(s.rstrip("/") + "/") for s in scope)
    return [p for p in changed if not in_scope(p)]

def setup_branch(root, branch):
    if git(root, "rev-parse", "--verify", branch).returncode == 0:
        git(root, "checkout", branch, check=True)
    else:
        git(root, "checkout", "-b", branch, "master", check=True)
    cur = git(root, "rev-parse", "--abbrev-ref", "HEAD").stdout.strip()
    if not cur.startswith("agent/"):
        raise RuntimeError(f"on branch '{cur}', not agent/*; refusing to continue")

def restore(root):
    git(root, "reset", "--hard", "HEAD", check=True)
    git(root, "clean", "-fd", "-e", "sessions", "-e", "STOP", check=True)

def commit(root, message):
    cur = git(root, "rev-parse", "--abbrev-ref", "HEAD").stdout.strip()
    if not cur.startswith("agent/"):
        raise RuntimeError(f"refusing to commit on '{cur}'")
    git(root, "add", "-A", check=True)
    git(root, "commit", "-m", message, check=True)

# ---------- execution ----------

def run_shell(cmd, root, timeout, outfile=None):
    """Run via cmd shell; on timeout kill the whole process tree. Returns rc (124=timeout)."""
    f = open(outfile, "a", encoding="utf-8", errors="replace") if outfile else subprocess.DEVNULL
    try:
        p = subprocess.Popen(cmd, cwd=str(root), shell=True,
                             stdout=f, stderr=subprocess.STDOUT)
        try:
            return p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)], capture_output=True)
            return 124
    finally:
        if outfile: f.close()

def should_stop(start, now, processed, consec_fails, stop_file, max_hours, max_tasks, max_fails):
    if stop_file: return "STOP file present"
    if now - start >= max_hours * 3600: return "wall-clock limit reached"
    if processed >= max_tasks: return "task limit reached"
    if consec_fails >= max_fails: return "too many consecutive failures"
    return ""

# ---------- main loop ----------

def run_loop(cfg):
    root = Path(cfg.root).resolve()
    tasks_dir = root / "tasks"
    today = datetime.date.today().isoformat()
    branch = "agent/" + today

    if cfg.dry_run:
        print(f"[dry-run] would use branch {branch}; worker cmd template: {cfg.worker_cmd}")
        files = task_files(tasks_dir) if tasks_dir.is_dir() else []
        order = []
        for f in files:
            try: t = parse_task(f.read_text(encoding="utf-8"))
            except ValueError as e:
                print(f"[dry-run] {f.name}: UNPARSEABLE ({e})"); continue
            print(f"[dry-run] {f.name}: status={t['status']} attempts={t['attempts']} "
                  f"scope={t['scope']} verify={t['verify']}")
            if t["status"] == "todo": order.append(f.name)
        print(f"[dry-run] run order: {order if order else 'nothing (queue empty)'}")
        return 0

    d = dirty_paths(root)
    if d:
        print("Refusing to start: working tree is dirty. Offending paths:")
        for p in d: print("  " + p)
        return 1
    setup_branch(root, branch)

    sess = root / "sessions"; rundir = sess / f"run-{today}"
    rundir.mkdir(parents=True, exist_ok=True)
    logf = sess / f"run-{today}.log"
    def log(line):
        stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(logf, "a", encoding="utf-8") as fh: fh.write(f"{stamp} {line}\n")
        print(line)

    if cfg.reviewer:
        log("reviewer: requested but not implemented yet; continuing without it")

    start = time.time()
    done = esc = retried = processed = consec = 0
    while True:
        reason = should_stop(start, time.time(), processed, consec, (root / "STOP").exists(),
                             cfg.max_hours, cfg.max_tasks, cfg.max_fails)
        if reason: log(f"stop: {reason}"); break
        f, t = pick_next(tasks_dir)
        if f is None: log("stop: queue empty"); break

        out = rundir / (f.stem + ".out")
        extra = ""
        if t["attempts"] > 0 and out.exists():
            tail = out.read_text(encoding="utf-8", errors="replace")[-1500:]
            extra = (" PREVIOUS ATTEMPT FAILED. Its output ends with: ---" 
                     + tail + "--- Fix what went wrong this time.")
        prompt = PROMPT.format(name=f.name, extra=extra).replace('"', "'")
        rc = run_shell(cfg.worker_cmd.format(prompt=prompt), root, cfg.task_timeout, str(out))

        failure = ""
        if rc == 124:
            failure = "worker timeout (process tree killed)"
        else:
            for v in t["verify"]:
                if run_shell(v, root, cfg.verify_timeout, str(out)) != 0:
                    failure = f"verify failed: {v}"; break
        if not failure:
            viol = scope_violations(dirty_paths(root), t["scope"])
            if viol: failure = "out-of-scope changes: " + ", ".join(viol)

        if not failure:
            write_header(f, "done", t["attempts"])
            commit(root, f"{f.stem}: {t['title'] or f.name}")
            done += 1; consec = 0; result = "done"
        else:
            restore(root)
            a = t["attempts"] + 1
            status = "escalate" if a >= MAX_ATTEMPTS else "todo"
            write_header(f, status, a)
            commit(root, f"{f.stem}: bookkeeping ({status}, attempts={a})")
            if status == "escalate": esc += 1; result = f"escalate attempts={a}"
            else: retried += 1; result = f"retry attempts={a}"
            consec += 1
            log(f"{f.stem} failure detail: {failure}")
        processed += 1
        log(f"{f.stem} result={result}")

    hours = (time.time() - start) / 3600
    (sess / "last_run.md").write_text(
        f"branch: {branch}\ndone: {done}\nescalated: {esc}\nretried: {retried}\n"
        f"tasks_processed: {processed}\ntime_used_hours: {hours:.2f}\n"
        f"reviewer: {'on' if cfg.reviewer else 'off'}\n", encoding="utf-8")
    log(f"summary: done={done} escalated={esc} retried={retried} hours={hours:.2f}")
    return 0

def main(argv=None):
    ap = argparse.ArgumentParser(description="Queue-mode runner. Loop commits; worker never does.")
    ap.add_argument("--root", default=str(Path(__file__).resolve().parent.parent))
    ap.add_argument("--worker-cmd", default=DEFAULT_WORKER,
                    help="launch template; {prompt} is replaced with the task prompt")
    ap.add_argument("--max-hours", type=float, default=8.0)
    ap.add_argument("--max-tasks", type=int, default=50)
    ap.add_argument("--max-fails", type=int, default=3)
    ap.add_argument("--task-timeout", type=int, default=2700)
    ap.add_argument("--verify-timeout", type=int, default=600)
    ap.add_argument("--reviewer", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    return run_loop(ap.parse_args(argv))

if __name__ == "__main__":
    sys.exit(main())