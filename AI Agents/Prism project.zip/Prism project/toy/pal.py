def is_palindrome(text):
    processed = text.replace(' ', '').lower()
    return processed == processed[::-1]
