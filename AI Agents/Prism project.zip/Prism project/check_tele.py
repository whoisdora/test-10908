import sys
try:
    m = loadfile('src_coins/TeleportPad.lua')()
    assert m.Teleport(1, 10, 10, 10), "Teleport failed"
    print('CHECK 502 PASS')
except Exception as e:
    print(e)
    sys.exit(1)