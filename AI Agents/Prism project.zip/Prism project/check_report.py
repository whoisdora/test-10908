import sys
sys.path.insert(0, 'lib')
try:
    from report import text_report
except Exception:
    sys.exit(1)
r = text_report('Hi there. Bye now.')
ok = isinstance(r, dict) and r.get('words')==4 and r.get('sentences')==2 and 'avg_word_length' in r
sys.exit(0 if ok else 1)
