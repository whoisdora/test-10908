import sys,re
try:
    s=open(r'src/CheckpointRegistry.lua',encoding='utf-8').read()
except Exception:
    sys.exit(1)
ok = 'local CheckpointRegistry' in s and 'return CheckpointRegistry' in s
for fn in ['register','get','count']:
    ok = ok and re.search(r'function CheckpointRegistry\.'+fn+r'\s*\(', s)
ok = ok and s.count('function') <= s.count('end')
sys.exit(0 if ok else 1)
