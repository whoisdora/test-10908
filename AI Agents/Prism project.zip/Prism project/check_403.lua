-- checker for src_coins/SpendService.lua
local Tracker = require('./src_coins/PlayerCoinTracker')
local Spend = require('./src_coins/SpendService')
assert(type(Spend.CanSpend) == 'function', 'CanSpend missing')
local p = { UserId = 7, Name = 'TestPlayer' }
Tracker.AddCoins(p, 10)
assert(Spend.CanSpend(p, 5) == true, 'sufficient funds must return true')
assert(Spend.CanSpend(p, 10) == true, 'exact funds must return true')
assert(Spend.CanSpend(p, 11) == false, 'overdraft must return false')
print('CHECK 403 PASS')