#!/usr/bin/env python3
import unittest
import os
import sys
import tempfile


class TestVaultCheck(unittest.TestCase):

    def setUp(self):
        self.test_base = tempfile.mkdtemp()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.test_base)

    def test_check_files_exist_pass(self):
        os.makedirs(os.path.join(self.test_base, "core"))
        os.makedirs(os.path.join(self.test_base, "templates"))
        with open(os.path.join(self.test_base, "AGENTS.md"), "w") as f:
            f.write("test")
        with open(os.path.join(self.test_base, "core", "state.md"), "w") as f:
            f.write("test")
        with open(os.path.join(self.test_base, "core", "decisions.md"), "w") as f:
            f.write("test")
        with open(os.path.join(self.test_base, "templates", "task.md"), "w") as f:
            f.write("test")

        from vault_check import check_files_exist
        results = check_files_exist(os.path.join(self.test_base))
        for r in results:
            self.assertTrue(r.startswith("PASS"), f"Expected PASS, got: {r}")

    def test_check_files_exist_fail_missing_file(self):
        os.makedirs(os.path.join(self.test_base, "core"))
        with open(os.path.join(self.test_base, "core", "state.md"), "w") as f:
            f.write("test")

        from vault_check import check_files_exist
        results = check_files_exist(os.path.join(self.test_base))
        found_fail = any(r.startswith("FAIL") for r in results)
        self.assertTrue(found_fail, "Expected at least one FAIL")

    def test_check_state_line_count_pass(self):
        os.makedirs(os.path.join(self.test_base, "core"))
        with open(os.path.join(self.test_base, "core", "state.md"), "w") as f:
            for i in range(50):
                f.write(f"line {i}\n")

        from vault_check import check_state_line_count
        results = check_state_line_count(os.path.join(self.test_base))
        for r in results:
            self.assertTrue(r.startswith("PASS"), f"Expected PASS, got: {r}")

    def test_check_state_line_count_fail(self):
        os.makedirs(os.path.join(self.test_base, "core"))
        with open(os.path.join(self.test_base, "core", "state.md"), "w") as f:
            for i in range(65):
                f.write(f"line {i}\n")

        from vault_check import check_state_line_count
        results = check_state_line_count(os.path.join(self.test_base))
        failed_found = any(r.startswith("FAIL") for r in results)
        self.assertTrue(failed_found, "Expected at least one FAIL")

    def test_check_state_date_format_pass(self):
        os.makedirs(os.path.join(self.test_base, "core"))
        with open(os.path.join(self.test_base, "core", "state.md"), "w") as f:
            f.write("STATE\n")
            f.write("\n")
            f.write("\n")
            f.write("updated: 2025-01-15\n")

        from vault_check import check_state_date_format
        results = check_state_date_format(os.path.join(self.test_base))
        for r in results:
            self.assertTrue(r.startswith("PASS"), f"Expected PASS, got: {r}")

    def test_check_state_date_format_fail_invalid_date(self):
        os.makedirs(os.path.join(self.test_base, "core"))
        with open(os.path.join(self.test_base, "core", "state.md"), "w") as f:
            f.write("STATE\n")
            f.write("\n")
            f.write("updated: YYYY-MM-DD\n")

        from vault_check import check_state_date_format
        results = check_state_date_format(os.path.join(self.test_base))
        failed_found = any(r.startswith("FAIL") for r in results)
        self.assertTrue(failed_found, "Expected at least one FAIL")

    def test_check_decisions_format_pass(self):
        os.makedirs(os.path.join(self.test_base, "core"))
        with open(os.path.join(self.test_base, "core", "decisions.md"), "w") as f:
            f.write("DECISIONS Append only, newest last.\n")
            f.write("Format: date | decision | reason | decided by\n")
            f.write("\n")
            f.write("2026-10-06 | Build continuity first | Highest gain | human\n")

        from vault_check import check_decisions_format
        results = check_decisions_format(os.path.join(self.test_base))
        for r in results:
            self.assertTrue(r.startswith("PASS"), f"Expected PASS, got: {r}")

    def test_check_decisions_format_fail_wrong_field_count(self):
        os.makedirs(os.path.join(self.test_base, "core"))
        with open(os.path.join(self.test_base, "core", "decisions.md"), "w") as f:
            f.write("DECISIONS\n")
            f.write("Format: date | decision | reason | decided by\n")
            f.write("2026-10-06 | Build first\n")

        from vault_check import check_decisions_format
        results = check_decisions_format(os.path.join(self.test_base))
        failed_found = any(r.startswith("FAIL") for r in results)
        self.assertTrue(failed_found, "Expected at least one FAIL")


if __name__ == "__main__":
    unittest.main()
