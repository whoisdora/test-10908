def word_count(text):
    return len(text.split())

def sentence_count(text):
    import re
    sentences = re.split(r'[.!?]', text)
    return sum(1 for s in sentences if s.strip())

def char_count(text):
    return len(text)