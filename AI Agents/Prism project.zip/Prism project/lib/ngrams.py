def bigrams(text):
    words = text.split()
    return [(words[i], words[i+1]) for i in range(len(words)-1)] if len(words) > 1 else []