from counts import word_count, sentence_count, char_count
from readability import avg_word_length, avg_sentence_length

def text_report(text):
    return {
        'words': word_count(text),
        'sentences': sentence_count(text),
        'chars': char_count(text),
        'avg_word_length': avg_word_length(text),
        'avg_sentence_length': avg_sentence_length(text),
    }
