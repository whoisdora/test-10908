def avg_word_length(text):
    words = text.split()
    if not words:
        return 0.0
    return float(sum(len(word) for word in words) / len(words))

import re

def avg_sentence_length(text):
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if s.strip()]
    if not sentences:
        return 0.0
    word_counts = [len(s.split()) for s in sentences]
    return float(sum(word_counts) / len(word_counts))