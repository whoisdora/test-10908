import collections

def top_words(text, n, stopwords):
    words = text.split()
    words = [word.lower() for word in words]
    filtered = [word for word in words if word not in stopwords]
    counts = collections.Counter(filtered)
    top = counts.most_common(n)
    sorted_top = sorted(top, key=lambda x: (-x[1], x[0]))
    return sorted_top