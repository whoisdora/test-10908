import sys
sys.path.insert(0, 'lib')
try:
    from topwords import top_words
except Exception:
    sys.exit(1)
r = top_words('the cat and the dog and the bird', 1, stopwords=['the','and'])
ok = r==[('cat',1)] or (len(r)==1 and r[0][1]==1)
r2 = top_words('a a a b b c', 2, stopwords=[])
ok = ok and r2==[('a',3),('b',2)]
sys.exit(0 if ok else 1)
