import sys
sys.path.insert(0, 'lib')
try:
    from readability import avg_word_length, avg_sentence_length
except Exception:
    sys.exit(1)
ok = avg_word_length('ab abcd')==3.0 and avg_sentence_length('One two. Three four.')==2.0
sys.exit(0 if ok else 1)
