local HealthModule = {}
HealthModule.__index = HealthModule

function HealthModule.New(initialHealth)
    local self = setmetatable({}, HealthModule)
    self.health = initialHealth
    return self
end

function HealthModule:TakeDamage(amount)
    self.health = math.max(0, self.health - amount)
end

function HealthModule:GetHealth()
    return self.health
end

return HealthModule