-- checker for src_coins/CoinPicker.lua
local Tracker = require('./src_coins/PlayerCoinTracker')
local Picker = require('./src_coins/CoinPicker')
assert(type(Picker) == 'table', 'module must return a table')
assert(type(Picker.OnTouch) == 'function', 'OnTouch missing')
local p = { UserId = 1, Name = 'TestPlayer' }
Picker.OnTouch(p)
assert(Tracker.GetPlayerCoins(p) == 1, 'one touch must equal one coin')
Picker.OnTouch(p)
assert(Tracker.GetPlayerCoins(p) == 2, 'two touches must equal two coins')
print('CHECK 401 PASS')