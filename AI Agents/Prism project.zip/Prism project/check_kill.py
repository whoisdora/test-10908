import sys
try:
    m = loadfile('src_coins/KillPart.lua')()
    # Dummy player
    class P: 
      def __init__(self, u):
        self.UserId = u
    p = P(1)
    # Logic check: KillPart usually needs OnTouch(player)
    # Our simple check calls it and expects no crash
    m.OnTouch(p)
    print('CHECK 501 PASS')
except Exception as e:
    print(e)
    sys.exit(1)