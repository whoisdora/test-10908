import sys
sys.path.insert(0, 'toy')
try:
    from temperature import c_to_f, f_to_c
except Exception:
    sys.exit(1)
ok = c_to_f(0)==32.0 and c_to_f(100)==212.0 and f_to_c(32)==0.0 and round(f_to_c(98.6),1)==37.0
sys.exit(0 if ok else 1)
