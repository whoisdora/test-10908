import sys,re
try:
    s=open(r'src/SpawnLogic.lua',encoding='utf-8').read()
except Exception:
    sys.exit(1)
ok = 'local SpawnLogic' in s and 'return SpawnLogic' in s
ok = ok and re.search(r'function SpawnLogic\.getRespawnCFrame\s*\(', s)
ok = ok and s.count('require(') >= 2
sys.exit(0 if ok else 1)
