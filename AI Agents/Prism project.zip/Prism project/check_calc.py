import sys
sys.path.insert(0, 'toy')
try:
    from calc import add, sub
except Exception:
    sys.exit(1)
sys.exit(0 if add(2,3)==5 and sub(10,4)==6 else 1)
