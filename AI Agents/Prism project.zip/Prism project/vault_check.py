#!/usr/bin/env python3
"""Check project memory files are valid before closing a session."""
import os
import re
import sys


def check_files_exist(basedir="."):
    required = ["AGENTS.md", "core/state.md", "core/decisions.md", "templates/task.md"]
    results = []
    for fname in sorted(required):
        if os.path.exists(os.path.join(basedir, fname)):
            results.append(f"PASS: {fname} exists")
        else:
            results.append(f"FAIL: {fname} not found")
    return results


def check_state_line_count(basedir="."):
    fpath = os.path.join(basedir, "core", "state.md")
    if not os.path.exists(fpath):
        return ["FAIL: cannot open core/state.md"]
    try:
        with open(fpath, "r", encoding="utf-8") as f:
            count = len([l for l in f.read().split("\n") if l.strip()])
        if count <= 60:
            return [f"PASS: core/state.md has {count} lines (<=60)"]
        return [f"FAIL: core/state.md has {count} lines (>60)"]
    except Exception as e:
        return [f"FAIL: cannot read core/state.md: {e}"]


def check_state_date_format(basedir="."):
    fpath = os.path.join(basedir, "core", "state.md")
    if not os.path.exists(fpath):
        return ["FAIL: cannot open core/state.md"]
    try:
        with open(fpath, "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f.readlines()]
        for line in lines:
            if line.startswith("updated:"):
                date_str = line.split(":", 1)[1].strip()
                if re.match(r"^\d{4}-\d{2}-\d{2}$", date_str):
                    return [f"PASS: core/state.md has valid updated: {date_str}"]
                return [f"FAIL: core/state.md date format invalid: {date_str!r}"]
        return ["FAIL: core/state.md missing updated: line"]
    except Exception as e:
        return [f"FAIL: cannot read core/state.md: {e}"]


def check_decisions_format(basedir="."):
    """Non-empty lines after Format: must be 4 fields; field 1 a YYYY-MM-DD date."""
    fpath = os.path.join(basedir, "core", "decisions.md")
    if not os.path.exists(fpath):
        return ["FAIL: cannot open core/decisions.md"]
    try:
        with open(fpath, "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f.readlines()]
        format_line_idx = -1
        for i, line in enumerate(lines):
            if line.startswith("Format:"):
                format_line_idx = i
                break
        if format_line_idx == -1:
            return ["FAIL: core/decisions.md missing Format: header"]
        results = []
        for line in lines[format_line_idx + 1:]:
            if not line.strip():
                continue
            fields = line.split(" | ")
            if len(fields) != 4:
                results.append(f"FAIL: {line!r} has {len(fields)} fields (expected 4)")
            elif not re.match(r"^\d{4}-\d{2}-\d{2}$", fields[0]):
                results.append(f"FAIL: {line[:50]}... bad date {fields[0]!r}")
            else:
                results.append(f"PASS: {line[:50]}...")
        if not results:
            results.append("PASS: core/decisions.md has no entries yet")
        return results
    except Exception as e:
        return [f"FAIL: cannot read core/decisions.md: {e}"]


def main(folder="."):
    os.chdir(folder)
    all_results = []
    for name, func in [
        ("files_exist", check_files_exist),
        ("state_line_count", check_state_line_count),
        ("state_date_format", check_state_date_format),
        ("decisions_format", check_decisions_format),
    ]:
        all_results.extend(func("."))
    for result in all_results:
        print(result)
    return 0 if not any(r.startswith("FAIL") for r in all_results) else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "."))