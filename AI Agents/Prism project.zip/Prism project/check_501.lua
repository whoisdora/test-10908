local KillPart = require('./src/KillPart')
assert(type(KillPart.Run) == 'function', 'Run function missing')
print('CHECK 501 PASS')
