import sys
sys.path.insert(0, 'toy')
try:
    from farewell import farewell
except Exception:
    sys.exit(1)
sys.exit(0 if farewell('World') == 'Goodbye, World!' else 1)
