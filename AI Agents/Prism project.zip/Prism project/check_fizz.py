import sys
sys.path.insert(0, 'toy')
try:
    from fizz import fizzbuzz
except Exception:
    sys.exit(1)
ok = fizzbuzz(15)=='FizzBuzz' and fizzbuzz(9)=='Fizz' and fizzbuzz(10)=='Buzz' and fizzbuzz(7)=='7'
sys.exit(0 if ok else 1)
