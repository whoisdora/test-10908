import sys
sys.path.insert(0, 'lib')
try:
    from ngrams import bigrams
except Exception:
    sys.exit(1)
ok = bigrams('a b c')==[('a','b'),('b','c')] and bigrams('solo')==[]
sys.exit(0 if ok else 1)
