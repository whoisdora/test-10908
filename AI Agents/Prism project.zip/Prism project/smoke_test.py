"""Smoke test for a local Ollama model. No dependencies, standard library only.

Usage:
    python smoke_test.py
    python smoke_test.py --model qwen3.5:9b --runs 5
    python smoke_test.py --model my-agent --host http://localhost:11434

Checks:
    1. Ollama is reachable and the model is installed
    2. Plain chat works (and reports generation speed)
    3. Tool calling works, repeated several times, because small models are flaky
"""
import argparse
import json
import sys
import time
import urllib.error
import urllib.request

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read a text file and return its contents.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative file path"}
                },
                "required": ["path"],
            },
        },
    }
]


def post(host, path, body, timeout=300):
    req = urllib.request.Request(
        host + path,
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def get(host, path, timeout=10):
    with urllib.request.urlopen(host + path, timeout=timeout) as r:
        return json.load(r)


def check_reachable(host, model):
    try:
        tags = get(host, "/api/tags")
    except Exception as e:
        print(f"FAIL  cannot reach Ollama at {host}: {e}")
        print("      Is Ollama running? Try: ollama serve")
        return False
    names = [m.get("name", "") for m in tags.get("models", [])]
    if not any(n == model or n.startswith(model + ":") or n.split(":")[0] == model for n in names):
        print(f"FAIL  model '{model}' not installed. Installed: {names or 'none'}")
        print(f"      Try: ollama pull {model}")
        return False
    print(f"PASS  Ollama reachable, model '{model}' installed")
    return True


def check_chat(host, model):
    body = {
        "model": model,
        "stream": False,
        "think": False,
        "messages": [{"role": "user", "content": "Reply with the single word: ready"}],
    }
    try:
        t0 = time.time()
        r = post(host, "/api/chat", body)
        wall = time.time() - t0
    except Exception as e:
        print(f"FAIL  plain chat error: {e}")
        return False
    text = (r.get("message", {}).get("content") or "").strip()
    n = r.get("eval_count", 0)
    dur = r.get("eval_duration", 0) / 1e9
    speed = f"{n / dur:.1f} tok/s" if dur > 0 else "n/a"
    print(f"PASS  plain chat replied: {text[:60]!r} ({speed}, {wall:.1f}s total)")
    return True


def one_tool_run(host, model):
    body = {
        "model": model,
        "stream": False,
        "think": False,
        "tools": TOOLS,
        "messages": [
            {
                "role": "system",
                "content": "You are a coding agent. Use the provided tools to act. Do not describe the call in text.",
            },
            {
                "role": "user",
                "content": "Read the file core/STATE.md using the read_file tool.",
            },
        ],
    }
    r = post(host, "/api/chat", body)
    msg = r.get("message", {})
    calls = msg.get("tool_calls") or []
    content = msg.get("content") or ""
    if calls:
        fn = calls[0].get("function", {})
        args = fn.get("arguments", {})
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except Exception:
                args = {}
        if fn.get("name") == "read_file" and "path" in args:
            return True, f"read_file(path={args['path']!r})"
        return False, f"wrong call: {fn}"
    if "<tool_call>" in content or "<function=" in content:
        return False, "tool call printed as text instead of executed"
    return False, f"no tool call; replied: {content[:80]!r}"


def check_tools(host, model, runs):
    passed = 0
    for i in range(1, runs + 1):
        try:
            ok, detail = one_tool_run(host, model)
        except Exception as e:
            ok, detail = False, f"error: {e}"
        print(f"  run {i}/{runs}: {'ok  ' if ok else 'FAIL'} {detail}")
        passed += ok
    rate = passed / runs
    verdict = "PASS" if rate == 1 else ("WARN" if rate >= 0.8 else "FAIL")
    print(f"{verdict}  tool calling: {passed}/{runs} ({rate:.0%})")
    return rate


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="qwen3.5:9b")
    p.add_argument("--host", default="http://localhost:11434")
    p.add_argument("--runs", type=int, default=5)
    a = p.parse_args()

    print(f"Testing {a.model} at {a.host}\n")
    if not check_reachable(a.host, a.model):
        sys.exit(1)
    if not check_chat(a.host, a.model):
        sys.exit(1)
    print("Tool calling:")
    rate = check_tools(a.host, a.model, a.runs)
    print("\nPaste this whole output back when asking for help.")
    sys.exit(0 if rate >= 0.8 else 2)


if __name__ == "__main__":
    main()
