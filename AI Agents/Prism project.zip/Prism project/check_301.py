import sys,re
try:
    s=open(r'src/Config.lua',encoding='utf-8').read()
except Exception:
    sys.exit(1)
ok = 'local Config' in s and 'return Config' in s
ok = ok and re.search(r'RESPAWN_DELAY\s*=', s) and re.search(r'CHECKPOINT_TAG\s*=', s)
sys.exit(0 if ok else 1)
