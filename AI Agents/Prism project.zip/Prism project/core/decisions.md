DECISIONS Append only, newest last.
Format: date | decision | reason | decided by

2026-10-06 | Build continuity and verification first, delay the custom gateway | Highest gain for least effort, add the gateway only if a concrete need appears | human
2026-10-07 | Worker never edits core/state.md and the loop does not either, human copies the numbers in | Keeps state.md trustworthy as human-maintained memory | human
2026-10-07 | Sandbox via separate Windows user deferred, runs stay attended with bash catch-all at ask until the pipeline is proven | Setup cost not justified before the system works, revisit before first unattended overnight run | human
2026-10-07 | USER_GUIDE and WORKFLOW moved out of the repo, one level up in the vault | Smaller world for the worker, docs stay visible in Obsidian | human
2026-10-07 | Overnight commit 7a2e375 reviewed and kept, stray files cleaned after | Changes were sane, tags before-overnight and baseline-before-fable preserve rollback points | human
2026-10-08 | M2 closed, deny rules proven in run mode, ask auto-rejects unattended, git* deny closes -c gap | Evidence runs 3x per probe, .env deny survived a PowerShell bypass attempt | human
2026-10-08 | M3 closed, runner with tests passes all exit criteria including hang-kill and STOP | Toy run evidence, done=2 escalated=1, master untouched | human
2026-10-08 | GOTCHA, gitignored paths must not also be pathspec-excluded in git add, git 2.55 hard-errors | Found when hang-test crashed mid-commit | human
2026-10-08 | M2 closed, deny rules proven in run mode, ask auto-rejects unattended, git* deny closes -c gap | Evidence runs 3x per probe, .env deny survived a PowerShell bypass attempt | human
2026-10-08 | M3 closed, runner with tests passes all exit criteria including hang-kill and STOP | Toy run evidence, done=2 escalated=1, master untouched | human
2026-10-08 | GOTCHA, gitignored paths must not also be pathspec-excluded in git add, git 2.55 hard-errors | Found when hang-test crashed mid-commit | human
2026-10-08 | M5 partial, first real worker task done, TASK-105 escalated and resolved, TASK-106 done by qwen | Harness proven with real model, acceptance 1 of 2 | human
2026-10-08 | Bash default allow behind deny-wall, whitelist approach killed worker subagents twice | Deny rules proven, loop plus scope check plus toy blast radius carry the risk | human
2026-10-08 | GOTCHA, task specs must state paths explicitly relative to repo root, worker assumed checker lived in tasks folder | TASK-106 failed on path guess, passed after explicit rewrite | human
2026-10-08 | M5 run complete, 1 of 3 first-try, 108 and 109 escalated and resolved, exit bar not met | Harness flawless across two unattended runs, worker acceptance is the bottleneck | human
2026-10-08 | GOTCHA, worker fabricated completion on TASK-109, claimed tests passed with no file written | Verify-driven loop caught it, never trust model self-report, tests decide | human
2026-10-08 | Next, tune worker before M6 planner, thinking mode and context split are prime suspects | Fabrication and dithering are thinking-model failure modes, planner cannot fix a lying worker | human
2026-10-08 | Amends 2026-10-07, state.md is tool-written only, humans and worker never edit it by hand, human notes live in notes folder | Manual edit broke format same day, formatting is load-bearing, trust tools not fingers | human
2026-10-08 | Tuning session, 8k context kept for 26 percent speed gain, variant minimal kept, no_think dead end, persistence prompt works, shell dialect prompt does not | TASK-110 escalated after bash-isms, webfetch attempt and npm run build on a python task, prompt levers exhausted | human
2026-10-08 | Next lever is the model itself, evaluate a non-thinking coder model as worker, qwen3.5:9b stays as fallback | 2 done of 7 real attempts on trivial tasks is the measured baseline | human
2026-10-08 | Worker is qwen3:8b, yardstick 3 of 3 first try in 3 minutes, replaces qwen3.5:9b at 2 of 7 | Tool-call gate passed, coder models without agent training are dead ends, qwen2.5-coder typed JSON as text | human
2026-10-08 | New rule, every candidate worker model must pass the tool-call gate before touching the queue | qwen2.5-coder burned 4 attempts on plumbing before the gate existed | human
2026-10-08 | M6 pipeline proven end to end, plan lint redcheck queue verify commit, textstats wave 4 of 5 first try, 205 escalated and resolved | Planner was fable, lint overlap downgraded to WARN for sequential waves | human
2026-10-08 | GOTCHA, qwen3:8b skips self-verify and freelances logic, attempt 2 globbed comma-joined patterns got false zero matches | But it refused to fabricate on missing deps and reported instead, loop verify carries the weight as designed | human
2026-10-08 | Obby wave complete, 4 of 5 first try, facade 305 escalated twice and resolved by hand | First real Luau project through the full pipeline, require-chain lesson from 205 held for 304 | human
2026-10-08 | GOTCHA confirmed twice, qwen3:8b writes then tells the human to run verify instead of running it | Candidate fix for next session, strengthen prompt verify wording or add loop-side pre-verify retry | human
2026-10-08 | TASK-306 verified in game, per-checkpoint debounce works, fast progress registers | Worker fix was correct all along, wrongly failed by corrupted checker | human
2026-10-08 | GOTCHA, checkers must never be written via cmd one-liners, regex brackets corrupt, use notepad or planner-written files | Corrupted check_306 failed a correct worker session and cost two attempts | human
2026-10-08 | Studio paste discipline, edit stopped only, verify line 1 fingerprint after every paste | Four assembly failures tonight were all clipboard or edit-during-play | human
2026-10-08 | TASK-306 verified in game, per-checkpoint debounce works, forward-only respawn kept as design | Worker fix was correct all along, wrongly failed by corrupted checker | human
2026-10-08 | GOTCHA, checkers must never be written via cmd one-liners, regex brackets corrupt, use notepad or planner-written files | Corrupted check_306 failed a correct worker session and cost two attempts | human
2026-10-08 | Approved, luau CLI install and Tier A local planner, no APIs ever, escalation stays human-fable | Tier A fallback is bigger local model or human planning only | human
