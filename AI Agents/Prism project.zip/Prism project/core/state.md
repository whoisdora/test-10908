STATE



updated: 2026-10-08

by: by human



deliverable: queue-mode runner, proven on toy tasks with real worker

phase: worker tuning before M6 planner



done criteria:

\[x] runner with tests, launcher, dry-run, 12 unit tests pass

\[x] unattended run completes, log and summary written, master untouched

\[ ] worker first-try acceptance above 60 percent on toy tasks

\[ ] thinking and context split tuned and measured



last session:

M5 run complete. 107 done first try, 108 and 109 escalated and resolved.

Harness flawless across two unattended runs: timeout kill, STOP file,

failure breaker, scope check, branch discipline all fired correctly.

Worker fabricated completion on TASK-109, verify caught it.



next 3 actions:

1\. Build tools/update\_state.py so humans never hand-edit this file

2\. Tune worker: disable or cap thinking, test 8k context for full-GPU fit

3\. Measure tuned worker on a fresh red-checked task before starting M6



open questions:

Can thinking be disabled or capped for qwen3.5:9b through OpenCode or Ollama?

Does 8k context put the model fully on GPU, and how much faster per task?



dead ends, do not redo:

An instruction not to commit does not stop the model. Permission rules do.

Tight bash whitelists kill worker sessions on the first unlisted command.

Never trust worker self-report, TASK-109 claimed done with no file, tests decide.



metrics (date | tasks | accepted first try | corrections | resume time):

2026-10-06 | 0 | - | - | -

2026-10-08 | 5 | 2 of 5 | 3 escalated, 2 model failure 1 by design | -

2026-10-08 | 1 task, 110 | 0 of 1 | escalated, resolved by hand | -
2026-10-08 | 3 tasks 111-113 | 3 of 3 | none | qwen3:8b seated
2026-10-08 | 5 tasks 201-205 | 4 of 5 | 205 escalated resolved | pipeline proven
2026-10-08 | 5 tasks 301-305 | 4 of 5 | 305 escalated resolved | first Luau wave
2026-10-08 | fix-task 306 | worker correct, harness wrongly failed it | checker corruption GOTCHA | playtest verified in game
