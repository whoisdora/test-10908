SPEC: obby checkpoint backbone, Luau ModuleScripts in src/

Goal: reusable checkpoint system for a Roblox obby. Pure module logic,
no Instances created in code, game wiring done by hand in Studio.
Modules: Config.lua (constants), CheckpointRegistry.lua (checkpoint storage
by number), PlayerProgress.lua (per-player furthest checkpoint, forward-only),
SpawnLogic.lua (respawn position from progress), Checkpoints.lua (facade with
init and onTouch, debounced).
Verification: Python text-pattern checks on the .lua files, no Lua runtime.
Human playtests in Studio. Worker must never glob for dependency files,
they exist when the task runs.
