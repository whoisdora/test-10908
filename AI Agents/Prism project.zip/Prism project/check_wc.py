import sys
sys.path.insert(0, 'toy')
try:
    from wordcount import count_words
except Exception:
    sys.exit(1)
sys.exit(0 if count_words('the cat sat')==3 and count_words('')==0 and count_words('  hi  ')==1 else 1)
