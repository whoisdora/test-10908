import sys
sys.path.insert(0, 'toy')
try:
    from reverser import reverse_words
except Exception:
    sys.exit(1)
ok = reverse_words('hello world')=='world hello' and reverse_words('a')=='a' and reverse_words('')==''
sys.exit(0 if ok else 1)
