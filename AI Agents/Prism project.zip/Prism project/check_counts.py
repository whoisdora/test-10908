import sys
sys.path.insert(0, 'lib')
try:
    from counts import word_count, sentence_count, char_count
except Exception:
    sys.exit(1)
ok = word_count('Hi there. Bye now.')==4 and sentence_count('Hi there. Bye now.')==2 and char_count('abc')==3
sys.exit(0 if ok else 1)
