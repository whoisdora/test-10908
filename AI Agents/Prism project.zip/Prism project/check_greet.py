import sys
sys.path.insert(0, 'toy')
try:
    from greet import greet
except Exception:
    sys.exit(1)
sys.exit(0 if greet('World') == 'Hello, World!' else 1)
