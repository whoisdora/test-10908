import pathlib, sys
sys.exit(0 if pathlib.Path('toy/output.txt').exists() else 1)
